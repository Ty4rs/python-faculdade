



document.querySelector("div").style.backgroundColor = "red"
