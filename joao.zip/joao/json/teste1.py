import json
import dataclasses



def salvar():
    nome = input("Qual o seu nome?")
    idade = int(input("Qual é a sua idade?"))
    salvar = int(input("1 para salvar e 0 para ler"))
    if(salvar ==1):
        pessoa = {
            "nome": nome,
            "idade": idade
        }
        with open("./json/teste.json", 'w', encoding='utf-8') as teste:
            json.dump(pessoa, teste, indent=4, ensure_ascii=False)
    elif(salvar==0):
        with open("./json/teste.json", 'r', encoding='utf-8') as teste:
            arquivo = json.load(teste)
            for i in range(len(arquivo)):
                print(arquivo[0])
    
    
    
    with open("teste.json", 'r', encoding="utf-8") as arq:
        json
    
    
    

    
print("ola")
salvar()



