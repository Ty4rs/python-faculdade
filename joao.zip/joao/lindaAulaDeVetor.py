from modulo import *

idades = []

while True:
    print('1 - Inclusão\n2 - Relatório\n3 - Sair')
    opcao = input('Opção: ')

    if opcao == '3':
        break

    elif opcao == '1':
        inclui(idades)

    elif opcao == '2':
        relatorio(idades)

    else:
        print('Opção Inválida!')