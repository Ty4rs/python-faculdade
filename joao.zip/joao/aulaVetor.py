from modulo import *
idades = []

while (True):
    print("1 - Inclusão \ 2 - Relatório \ 3 - Média \ 4 - Sair")
    opcao = int(input())
    
    if opcao ==1:
        inclui(idades)
    elif opcao ==2:
        relatorio(idades)
    
    elif opcao ==3:
        media(idades)
    
    elif opcao ==4:
        break
    else: 
        print("Opção inválida!")