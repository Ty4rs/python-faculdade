import json


class cachorro():
    def __init__(this, nome, raca):
        this.nome = nome
        this.raca = raca



def adicionarDog(dog):
    
    listaCachorros = []
    with open("dog.json", 'r', encoding='utf-8') as arqd:
        listaCachorros = json.load(arqd)
        
    listaCachorros.append(dog.__dict__)
    
    with open("dog.json", 'w', encoding='utf-8') as arqv:
        json.dump(listaCachorros, arqv, indent=4, ensure_ascii=False)
        
        
caramelo = cachorro("caramel", "vira-lata")

adicionarDog(caramelo)
    



