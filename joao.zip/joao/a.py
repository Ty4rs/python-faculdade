def abc(f):
    print("Iniciar")
    f()

    print("Fim")

@Controller
def somar():
    print("Função")gdhugd
    fhiuhjf
    fjihgjio
    

somar()



