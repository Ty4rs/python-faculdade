def inclui(vetor):
    for _ in range(3):
        vetor.append(int(input("Idade: ")))
    

def relatorio(vetor):
    if len(vetor) ==0:
        print("nâo há elementos cadastrados.")
        
    else: 
        for i in vetor:
            print(f"Elemento {i + 1}: {vetor[i]}")
            
            
            
def media(vetor):
    valor = 0
    if len(vetor) == 0:
        print("Elemento vazio.")
        
    else:
        for i in range(len(vetor)):
            valor += vetor[i]
        valor = valor/ len(vetor)
        print(f"A média é {valor}")
         